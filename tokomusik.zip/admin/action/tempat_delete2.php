<?php
include "koneksi.php";
error_reporting(0);
ini_set('display_errors', '0');

$id = $_GET['id_tempatwisata'];
$sql = "DELETE FROM tbl_tempatwisata WHERE id_tempatwisata = '$id'";
$hasil = mysqli_query($conn, $sql);
    if($hasil){
        //echo "sukses";
      header("location:../?page=daftar-tempat-praktik&hapus=sukses");
    }
    else{
        //echo "gagal";
      header("location:../?page=daftar-tempat-praktik&hapus=gagal");
    }
 ?>

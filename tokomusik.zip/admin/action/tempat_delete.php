<?php 
include "koneksi.php";
$id = $_GET['id'];




	$sql = "DELETE FROM  `tempat_praktik` where id_praktik = '$id' ";
$hasil = mysqli_query($conn, $sql);


    if($hasil){
        //echo "sukses";
      header("location:../?page=daftar-tempat-praktik&hapus=sukses");
    }
    else{
        //echo "gagal";
      header("location:../?page=daftar-tempat-praktik&hapus=gagal");
    }

?>